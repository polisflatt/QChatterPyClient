# Constants for directories

SERVER_IP_DNS = "http://polisflatt.servehttp.com/QChatter/QChatterServer/"
CHANNELS_DIR = "Channel/"
MESSAGES_DIR = "Message/"
